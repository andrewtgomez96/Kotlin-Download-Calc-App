package com.example.angomez.mini_app1

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.EditText
import android.widget.TextView
import android.text.TextWatcher
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //declarations of text view file size and network speed
        val tvNS = nSpeed as EditText
        val tvFS = fSize as EditText

        //The TextChangeListener for changes to the File Size TextView
        tvFS.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                //error checking for nullptr exception and empty case
                if (s != null && !s.toString().equals("", ignoreCase = true)) {
                    updateCalculation(tvNS, tvFS)
                }
            }
        })

        //The TextChangeListener for changes to the Network Speed TextView
        tvNS.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {

            }

            override fun afterTextChanged(s: Editable?) {
                //error checking for nullptr exception and empty case
                if (s != null && !s.toString().equals("", ignoreCase = true)) {
                    updateCalculation(tvNS, tvFS)
                }
            }
        })

    }

    //function that is called to update the calculation of the download time as the input changes
    fun updateCalculation(tvNS: EditText, tvFS: EditText) {

        val printTime = dlSeconds as TextView
        //makes sure length of both is valid to avoid crashing on null
        if (tvNS.text.length > 0 && tvFS.text.length > 0) {

            val networkSpeed = Integer.parseInt(tvNS.text.toString())
            val fileSize = Integer.parseInt(tvFS.text.toString())


            val perByteSpeed = networkSpeed * Math.pow(10.0, 6.0) / 8
            val sizeInBytes = fileSize * Math.pow(2.0, 20.0)

            var downloadTime = sizeInBytes / perByteSpeed
            downloadTime = Math.round(downloadTime * 10) / 10.0

            //call to extension function
            printTime.setTime(downloadTime, printTime)

        }
        else{
            printTime.setTime(0.0, printTime)
        }
    }
}

//extension function for TextView to set text of the view given a Double
fun TextView.setTime(downloadTime: Double, printTime: TextView){ printTime.text = java.lang.Double.toString(downloadTime) }

